<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'biometrico');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (mysqli_connect_errno()){
	echo "mala conexion:" . mysqli_connect_error();
	die();
}

$stmt = $conn->prepare ("SELECT id_empleado, nombre, apellido, cedula, observacion, imagen FROM empleados");
$stmt->execute();
$stmt->bind_result(	$id_empleado, $nombre, $apellido, $cedula, $observacion, $imagen);
$emple=array();

while ($stmt->fetch()) {
	$temp=array();
	$temp['id_empleado']=$id_empleado;
	$temp['nombre']=$nombre;
	$temp['apellido']=$apellido;
	$temp['cedula']=$cedula;
	$temp['observacion']=$observacion;
	$temp['imagen']=$imagen;
	array_push($emple, $temp);

	# code...
}

echo json_encode($emple);
?>