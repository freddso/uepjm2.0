<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'biometrico');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (mysqli_connect_errno()){
	echo "mala conexion:" . mysqli_connect_error();
	die();
}

$cedula=$_GET['cedula'];


$stmt = $conn->prepare ("select id_marcaciones,concat(nombre ,' ', apellido) as nombre, fecha, dm_nombre as observacion, cedula from marcaciones m , empleados e , detalle_marcacion dm where e.id_empleado = m.id_empleado and dm.id_detalle_marcacion = m.id_detalle_marcacion and  cedula= '{$cedula}';");
$stmt->execute();
$stmt->bind_result($id_marcaciones, $nombre, $fecha, $observacion, $cedula2);
$marcacion=array();

while ($stmt->fetch()) {
	$temp=array();
	$temp['id_marcaciones']=$id_marcaciones;
	$temp['nombre']=$nombre;
	$temp['fecha']=$fecha;
	$temp['observacion']=$observacion;
	$temp['cedula']=$cedula2;
	array_push($marcacion, $temp);

	# code...
}

echo json_encode($marcacion);
?>