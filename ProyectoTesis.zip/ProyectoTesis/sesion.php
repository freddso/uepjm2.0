<?PHP
$hostname="localhost";
$database="biometrico";
$username="root";
$password="";
$json=array();
	if(isset($_GET["user"]) && isset($_GET["pwd"])){
		$user=$_GET['user'];
		$pwd=$_GET['pwd'];
		
		$conexion=mysqli_connect($hostname,$username,$password,$database);
		
		$consulta="SELECT e.user, e.pwd, e.nombre, e.apellido, e.cedula, e.telefono, e.observacion, r.id_rol FROM empleados e, rol_empleados r WHERE e.id_empleado=r.id_empleado and  e.user= '{$user}' AND e.pwd = '{$pwd}'";
		$resultado=mysqli_query($conexion,$consulta);

		if($consulta){
		
			if($reg=mysqli_fetch_array($resultado)){
				$json['datos'][]=$reg;
				
			}
			mysqli_close($conexion);
			echo json_encode($json);
		}



		else{
			$results["user"]='';
			$results["pwd"]='';
			$results["nombre"]='';
			$results["apellido"]='';
			$results["cedula"]='';
			$results["telefono"]='';
			$results["observacion"]='';
			$results["id_rol"]='';
			$json['datos'][]=$results;
			echo json_encode($json);
		}
		
	}
	else{
			$results["user"]='';
			$results["pwd"]='';
			$results["nombre"]='';
			$results["apellido"]='';
			$results["cedula"]='';
			$results["telefono"]='';
			$results["observacion"]='';
			$results["id_rol"]='';
			$json['datos'][]=$results;
			echo json_encode($json);
		}
?>