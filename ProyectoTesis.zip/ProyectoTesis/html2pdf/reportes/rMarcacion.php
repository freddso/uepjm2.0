<?php 

	$conexion=mysqli_connect('localhost:3306','root','','biometrico');

 ?>
<!DOCTYPE html>
<html lang="es">
<head>
	<link rel="stylesheet" type="text/css" href="../css/Estilo.css">
	<meta charset="UTF-8">
	<title>PDF</title>
	<style type="text/css">
		



     
	</style>

</head>
<body>
<p> <strong><u>UNIDAD EDUCATIVA "GRAL. PEDRO J MONTERO"</u></strong></p>
 <br>  
 <div class="form-group">

    <label for="txtfecha" class="col-sm-2 control-label">Fecha:</label>

    <div class="col-sm-4">

    <input type="date" id="txtfecha" name="txtfecha" class="form-control" value="<?php echo date('Y-n-j'); ?>" />

    </div>
</div>	
<br>
     <form name="listamarcacion">
        <table border="2">
         	<tr>
				<th colspan="3
                " style="border:1px #000 dotted;padding:20px;color:#030;" > <h2>Marcacion de asistecia del personal laboral.</h2></th>
			</tr>
  			<tr>
				<th style="border:1px #000 dotted;padding:10px;color:#030;">Empleado</th>
				<th style="border:1px #000 dotted;padding:10px;color:#030;">Fecha</th>
				<th style="border:1px #000 dotted;padding:10px;color:#030;">Observacion</th>
			</tr>
    			<tbody>
    				<?php   
    					$sql="select id_marcaciones,
concat(nombre ,' ', apellido) as nombre,
fecha, 
 dm_nombre as observacion
from marcaciones m , empleados e , detalle_marcacion dm where e.id_empleado = m.id_empleado and dm.id_detalle_marcacion = m.id_detalle_marcacion;";
    					$result=mysqli_query($conexion,$sql);
    					
    
    					while( $mostrar =mysqli_fetch_array($result) ) {
    					 ?>
    							    
    					<tr style="border:1px #000 dotted;padding:10px;color:#030;">
    						<td style="border:1px #000 dotted;padding:10px;color:#030;"><?php echo $mostrar['nombre'] ?></td>
    						<td style="border:1px #000 dotted;padding:10px;color:#030;"><?php echo $mostrar['fecha'] ?></td>
    						<td style="border:1px #000 dotted;padding:10px;color:#030;"><?php echo $mostrar['observacion'] ?></td>
    					</tr>
    				<?php 
    				}
    				 ?>
    				
    			</tbody>
			 </table>
     
        
     </form>
          

</body>
</html>