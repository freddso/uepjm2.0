<?php 

	$conexion=mysqli_connect('localhost:3306','root','','biometrico');

 ?>
<!DOCTYPE html>
<html lang="es">
<head>
	<link rel="stylesheet" type="text/css" href="../css/Estilo.css">
	<meta charset="UTF-8">
	<title>PDF</title>
	<style type="text/css">
		
	

		body{
			background: blue;
		}


     }
	</style>

</head>
<body>
<p> <strong><u>UNIDAD EDUCATIVA "GRAL. PEDRO J MONTERO"</u></strong></p>
 <br>  
 <div class="form-group">

    <label for="txtfecha" class="col-sm-2 control-label">Fecha:</label>

    <div class="col-sm-4">

    <input type="date" id="txtfecha" name="txtfecha" class="form-control" value="<?php echo date('Y-n-j'); ?>" />

    </div>
<br>
</div>	
		 <form>
            
          <table  style="background-image: '../img/imgReporte.jpg'">
          			
					<thead  >
						<tr name="tabla1">
          				<th colspan="6" style="border:1px #000 dotted;padding:20px;color:#030;" > <h2>LISTA DE EMPLEADOS.</h2></th>
          			</tr>
          			<tr>
							<th style="border:1px #000 dotted;padding:10px;color:#030;">Cedula</th>
							<th style="border:1px #000 dotted;padding:10px;color:#030;">Nombre</th>
							<th style="border:1px #000 dotted;padding:10px;color:#030;">Apellido</th>
							<th style="border:1px #000 dotted;padding:10px;color:#030;">Direccion</th>
							<th style="border:1px #000 dotted;padding:10px;color:#030;">Telefono</th>
							<th style="border:1px #000 dotted;padding:10px;color:#030;">Area</th>
						</tr>
					</thead>
					
					<tbody>
						<?php 
							$sql="select cedula, nombre, apellido, direccion, telefono, observacion from biometrico.empleados where estado='A';";
							$result=mysqli_query($conexion,$sql);
							

							while( $mostrar =mysqli_fetch_array($result) ) {
							 ?>

							<tr style="border:1px #000 dotted;padding:10px;color:#030;">
								<td style="border:1px #000 dotted;padding:10px;color:#030;"><?php echo $mostrar['cedula'] ?></td>
								<td style="border:1px #000 dotted;padding:10px;color:#030;"><?php echo $mostrar['nombre'] ?></td>
								<td style="border:1px #000 dotted;padding:10px;color:#030;"><?php echo $mostrar['apellido'] ?></td>
								<td style="border:1px #000 dotted;padding:10px;color:#030;"><?php echo $mostrar['direccion'] ?></td>
								<td style="border:1px #000 dotted;padding:10px;color:#030;"><?php echo $mostrar['telefono'] ?></td>
								<td style="border:1px #000 dotted;padding:10px;color:#030;"><?php echo $mostrar['observacion'] ?></td>
							</tr>
						<?php 
						}
						 ?>
						
					</tbody>
            </table>
            
          </form>

</body>
</html>