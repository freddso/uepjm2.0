<?php
include 'conexion.php';

//$id_empleado=$_GET['id_empleado'];
$consulta="select cedula, nombre, apellido, telefono from empleados WHERE id_empleado='0'";
$resultado=$conexion ->query($consulta);

while($fila = $resultado ->fetch_array()){
	$usuario[] = array_map('utf8_encode', $fila);
}
echo json_encode($usuario);
$resultado->close();

 ?>