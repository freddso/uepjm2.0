<?php
include 'conexion.php';
$id_empleado=$_POST['id_empleado'];

//$usu_usuario="aroncal@gmail.com";
//$usu_password="12345678";

$sentencia=$conexion->prepare("SELECT id_rol FROM rol_empleados R  WHERE id_empleado=? AND estado='A'");
$sentencia->bind_param('ss',$id_empleado);
$sentencia->execute();

$resultado = $sentencia->get_result();
if ($fila = $resultado->fetch_assoc()) {
         echo json_encode($fila,JSON_UNESCAPED_UNICODE);     
}
$sentencia->close();
$conexion->close();
?>