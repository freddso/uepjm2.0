<?php
include 'conexion.php';
		$user=$_GET['user'];
		$pwd=$_GET['pwd'];

$sentencia=$conexion->prepare("SELECT user, pwd, names FROM usuarios WHERE user= '{$user}' AND pwd = '{$pwd}'");

$sentencia->execute();

$resultado = $sentencia->get_result();
if ($fila = $resultado->fetch_assoc()) {
         echo json_encode($fila,JSON_UNESCAPED_UNICODE);     
}
$sentencia->close();
$conexion->close();
?> 

