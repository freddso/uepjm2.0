<?PHP
$hostname="localhost";
$database="biometrico";
$username="root";
$password="";
$json=array();
	if(isset($_GET["usuario"]) && isset($_GET["contrasena"])){
		$usuario=$_GET['usuario'];
		$contrasena=$_GET['contrasena'];
		
		/*$usuario="freddso";
		$password="0953555414";*/

		$conexion=mysqli_connect($hostname,$username,$password,$database);
		
		$consulta="SELECT usuario, contrasena, estado FROM usuario WHERE usuario= '{$usuario}' AND contrasena = '{$contrasena}'";
		$resultado=mysqli_query($conexion,$consulta);

		if($consulta){
		
			if($reg=mysqli_fetch_array($resultado)){
				$json['datos'][]=$reg;
			}
			mysqli_close($conexion);
			echo json_encode($json);
		}

		else{
			$results["usuario"]='';
			$results["contrasena"]='';
			$results["estado"]='';
			$json['datos'][]=$results;
			echo json_encode($json);
		}
		
	}
	else{
		   	$results["usuario"]='';
			$results["contrasena"]='';
			$results["estado"]='';
			$json['datos'][]=$results;
			echo json_encode($json);
		}
?>